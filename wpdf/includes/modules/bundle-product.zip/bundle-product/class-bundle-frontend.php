<?php

namespace DispatchForge\Modules;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class BundleProductFrontend
{
    public function __construct()
    {
        add_action('init', function() {
            if (!class_exists('WooCommerce')) {
                return;
            }
        });
        add_filter('woocommerce_product_get_stock_quantity', [$this, 'set_bundle_stock'], 10, 2);
        add_filter('woocommerce_short_description', [$this, 'append_bundle_to_short_description'], 10, 2);
        add_action('woocommerce_single_product_summary', [$this, 'manual_add_to_cart_display'], 30);
        add_filter('woocommerce_product_has_attributes', [$this, 'enable_bundle_attributes'], 10, 2);
        add_action('woocommerce_single_product_summary', [$this, 'display_bundle_components'], 25);
        add_action('woocommerce_single_product_summary', [$this, 'debug_hooks'], 5);

        $this->debug_log("BundleProductFrontend initialized");

        add_filter('woocommerce_is_purchasable', function ($purchasable, $product) {
            if ($product->get_type() === 'bundle') {
                return true;
            }
            return $purchasable;
        }, 10, 2);

        add_filter('woocommerce_locate_template', [$this, 'override_bundle_template'], 10, 3);
    }

    private function debug_log($message)
    {
        if (WP_DEBUG === true) {
            error_log(date('Y-m-d H:i:s') . ' - ' . $message . "\n", 3, WP_CONTENT_DIR . '/debug.log');
        }
    }

    public function debug_hooks()
    {
        $this->debug_log("woocommerce_single_product_summary hook triggered");
    }

    public function manual_add_to_cart_display()
    {
        global $product;
        if (!$product || !$product->get_id()) {
            $this->debug_log("Product object is not available.");
            return;
        }

        $this->debug_log("Checking product purchase conditions for product ID: " . $product->get_id());

        if ($product->get_type() === 'bundle') {
            if (!$product->is_purchasable()) {
                $this->debug_log("Product is not purchasable.");
            } else {
                $this->debug_log("Product is purchasable.");
            }

            if (!$product->is_in_stock()) {
                $this->debug_log("Product is out of stock.");
            } else {
                $this->debug_log("Product is in stock.");
            }

            if (!$product->get_price()) {
                $this->debug_log("Product does not have a price set.");
            } else {
                $this->debug_log("Product price: " . $product->get_price());
            }

            woocommerce_template_single_add_to_cart();
        }
    }

    public function override_bundle_template($template, $template_name, $template_path)
    {
        global $product;
        if ($template_name === 'single-product/add-to-cart/simple.php' && $product->get_type() === 'bundle') {
            $this->debug_log("Overriding bundle template for product ID: " . $product->get_id());
            return plugin_dir_path(__FILE__) . 'assets/templates/bundle-product-template.php';
        }
        return $template;
    }
    
    public function display_bundle_components()
{
    global $product;
    $this->debug_log("Entering display_bundle_components for product ID: " . $product->get_id());
    
    if (!$product || !$product->get_id()) {
        $this->debug_log("Product is not valid.");
        return;
    }

    $bundle_components = get_post_meta($product->get_id(), '_bundle_components', true);
    if (is_string($bundle_components)) {
        $bundle_components = json_decode($bundle_components, true);
    }

    if (!empty($bundle_components)) {
        echo '<div class="bundle-components-list"><strong>Included in this bundle:</strong><ul>';
        foreach ($bundle_components as $component_id => $component) {
            $product_component = wc_get_product($component_id);
            if ($product_component) {
                echo '<li>' . esc_html($product_component->get_name()) . ' x ' . esc_html($component['qty']) . '</li>';
            }
        }
        echo '</ul></div>';
    }
}
public function append_bundle_to_short_description($description, $product = null)
{
    if (!$product || !$product->get_id()) {
        $this->debug_log("Product object is not valid.");
        return $description;
    }

    $this->debug_log("Appending bundle description for product ID: " . $product->get_id());

    if ($product->get_type() === 'bundle') {
        $bundle_components = get_post_meta($product->get_id(), '_bundle_components', true);
        if (is_string($bundle_components)) {
            $bundle_components = json_decode($bundle_components, true);
        }

        if (!empty($bundle_components)) {
            $description .= '<div class="bundle-details"><strong>Bundle includes:</strong><ul>';
            foreach ($bundle_components as $component_id => $component) {
                $product_component = wc_get_product($component_id);
                if ($product_component) {
                    $description .= '<li>' . esc_html($product_component->get_name()) . ' x ' . esc_html($component['qty']) . '</li>';
                }
            }
            $description .= '</ul></div>';
        }
    }

    return $description;
}

public function set_bundle_stock($stock, $product)
{
    if (!$product || !$product->get_id()) {
        $this->debug_log("Product object is not valid.");
        return 0; // Ensure stock defaults to 0 instead of causing an error
    }

    $this->debug_log("Entering set_bundle_stock for product ID: " . $product->get_id());

    if ($product->get_type() === 'bundle') {
        $bundle_components = get_post_meta($product->get_id(), '_bundle_components', true);
        if (is_string($bundle_components)) {
            $bundle_components = json_decode($bundle_components, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $this->debug_log("JSON decode error: " . json_last_error_msg());
                return $stock;
            }
        }

        $stock_levels = [];
        foreach ($bundle_components as $component_id => $component) {
            $component_stock = get_post_meta($component_id, '_stock', true);
            $this->debug_log("Component ID: $component_id, Stock: $component_stock");
            if ($component_stock !== '') {
                $stock_levels[] = floor($component_stock / max(1, $component['qty']));
            }
        }

        $final_stock = !empty($stock_levels) ? min($stock_levels) : 0;
        $this->debug_log("Final bundle stock: $final_stock");
        return $final_stock;
    }

    return $stock;
}



}

new BundleProductFrontend();

?>
